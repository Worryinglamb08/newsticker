<?php
/**
 * newsticker
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 *
 * @category  PrestaToolkit
 * @package   newsticker
 * @author    PrestaToolkit
 * @copyright Copyright 2019 © PrestaToolkit All right reserved
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*/

if (!defined('_PS_VERSION_'))
exit;
include_once(dirname(__FILE__).'/model/NewsTickersModel.php');
class NewsTicker extends Module
{
	public function __construct()
	{
	$this->name = 'newsticker';
	$this->tab = 'front_office_features';
	$this->version = '2.0.0';
	$this->author = 'PrestaToolkit';
	$this->bootstrap = true;
	parent::__construct();
	$this->displayName = $this->l('News Ticker');
	$this->description = $this->l('Stylish News Ticker for your website.');
	$this->module_key = 'fcb9913b032d188cb12606474c8198b2';
	}

	public function install()
	{
		return (parent::install() && $this->registerHook('displayRightColumn') && $this->registerHook('displayHome') && $this->registerHook('header') && $this->installTab() && $this->installDB());
	}

	public function uninstall()
	{
		return (parent::uninstall() && $this->uninstallTab() && $this->uninstallDB());
	}

	public function installTab()
	{
		$tab = new Tab();
		$tab->active = 1;
		$tab->class_name = 'AdminNewsTicker';
		$tab->name = array();
		foreach (Language::getLanguages(true) as $lang)
			$tab->name[$lang['id_lang']] = 'News Ticker';
		$tab->id_parent = (int)Tab::getIdFromClassName('AdminParentPreferences');
		$tab->module = $this->name;
		$tab->add();
		return true;
	}

	public function uninstallTab()
	{
		$id_tab = (int)Tab::getIdFromClassName('AdminNewsTicker');
		if ($id_tab)
		{
			$tab = new Tab($id_tab);
			return $tab->delete();
		}
		else
			return false;
	}

	public function installDb()
	{
		$return = true;
		$return &= Db::getInstance()->execute(' CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'newsticker` (
					`id_newsticker` int(10) NOT NULL auto_increment,
					`active` int(10) NOT NULL,
					PRIMARY KEY (`id_newsticker`)
			) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8;');
		$return &= Db::getInstance()->execute(' CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'newsticker_lang` (
				`id_newsticker` int(10) NOT NULL,
				`id_lang` int(10) NOT NULL,
				`news` text,
			PRIMARY KEY (`id_newsticker`, `id_lang`)
		) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8;');
		return $return;
	}

	public function uninstallDB()
	{
		return (Db::getInstance()->execute('DROP TABLE IF EXISTS `'._DB_PREFIX_.'newsticker`') && Db::getInstance()->execute('DROP TABLE IF EXISTS `'._DB_PREFIX_.'newsticker_lang`'));
	}

	public function getContent()
	{
		$hint = (true === Tools::version_compare(_PS_VERSION_, '1.7.0.0', '>=')) ? '<div class="panel"><p>Please find the menu to add news under Shop Parameters - General</p></div>' : '';
		$this->html = $this->display(__FILE__, 'views/templates/hook/add.tpl');
		return $hint.$this->html;
	}
	
	public function hookDisplayHome()
	{
		$obj = new NewsTickers;
		$news = $obj->getAllNews();
		$this->context->smarty->assign(array(
			'news' => $news,
		));
		if (Tools::version_compare(_PS_VERSION_, '1.7.0.0', '>=') == true) {
			$force_ssl = (Configuration::get('PS_SSL_ENABLED') && Configuration::get('PS_SSL_ENABLED_EVERYWHERE'));
			$this->context->smarty->assign('base_dir', _PS_BASE_URL_.__PS_BASE_URI__);
			$this->context->smarty->assign('base_dir_ssl', _PS_BASE_URL_SSL_.__PS_BASE_URI__);
			$this->context->smarty->assign('force_ssl', $force_ssl);
		}
		return $this->display(__FILE__, 'hook.tpl');
	}

	public function hookHeader($params)
	{
		return ($this->context->controller->addCSS($this->_path.'views/css/front.css') || $this->context->controller->addJS($this->_path.'views/js/front.js'));
	}
}